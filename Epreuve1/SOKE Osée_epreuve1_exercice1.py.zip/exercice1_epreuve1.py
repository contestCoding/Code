#coding:utf-8
"""
   Author: SOKE Osé Jacques
   Num:98455258
"""
   #Resolution d'equation de type ax + b = c
def equation_lineaire(a,b,c):
    if (a==0):
        if(b==c):
            return 'More than one solution'
        else:
            return'No solution'
    else:
        return "x={}".format(round(((c-b)/a),6))

reponse=[]
a=0
b=0
c=0
taille=input()
taille=int(taille)

for i in range (0,taille):
    equation=input()  
    equation=equation.split(' ')
    a=equation[0]
    b=float(equation[2])
    c=float(equation[4])
    a=a.replace('x','')
    print(len(a))
    a=float(a)
    reponse.append(equation_lineaire(a,b,c))

for i in range(0,len(reponse)):
    print("Equation n°{} \n{} \n".format(i+1,reponse[i]))
