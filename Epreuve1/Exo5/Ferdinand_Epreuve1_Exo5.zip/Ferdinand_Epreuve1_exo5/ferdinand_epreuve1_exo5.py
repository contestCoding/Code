
iteration=True
listeEntre=[]

while(iteration==True):
    val=input()
    if val != '#':
        listeEntre.append(val)
        iteration=True
    else:
        iteration=False

for elt in listeEntre:
    res=elt.split(" ")
    number=res[1]
    
    if number[0]==number[1]:
        if number[2]==number[3] and number[1]==number[2]:
            print(number[1],' ', number[1],' glued')
        elif number[2]==number[3] and number[1] != number[2]:
            print(number[1],' ',number[1],' glued and ',number[2],' ',number[3],' glued')
        elif number[2] != number[3]:
            print(number[0],' ', number[1],' glued')

    elif number[1]==number[2]:
        print(number[1],' ', number[1],' glued')

    elif number[2]==number[3]:
        print(number[2],' ', number[3],' glued')
    else:
        pass


