             Produit par GBESSI Kénédy
             Num:+229 94346187
1-avoir au moins python version 3.6
2-pour l'executer, il faut taper: python3 Kenedy_Epreuve1_Exo2.py
