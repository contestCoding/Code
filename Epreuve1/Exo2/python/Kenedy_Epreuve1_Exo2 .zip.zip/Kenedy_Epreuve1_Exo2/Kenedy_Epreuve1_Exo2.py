#code
p=int(input())
result=[]
reName=[]
maxi=[]
for i in range(0,p):
    lineValue=[]
    lineValue.append(input())
    b=lineValue[0].split(' ')
    m=int(b[0])
    n=int(b[1])
    nom=[]
    for k in range(0,m):
        nom.append(input())
    stokName=[]
    stokValue=[]
    for j in range(0,n):
        vote=input()
        value=vote.split(' ')
        stokName.append(value[0])
        stokValue.append(value[1])
    posit=[]
    S=0
    for l in range(0,m):
        for s in range(0,n):
            if nom[l]==stokName[s]:
                S=S+int(stokValue[s])
        posit.append(S)
        S=0
    ma=max(posit)
    maxi.append(ma)
    sum=0
    ran=''
    for e in range(0,m):
        if ma==posit[e]:
            sum=sum+1
            ran=nom[e]
    if sum>=2:
        result.append(1)
        reName.append('nul')
    else:
        result.append(0)
        reName.append(ran)
for i in range(0,p):
    if result[i]==1:
        print('VOTE {} : THERE IS A DILEMMA'.format(i+1))
    else:
        print('VOTE {} : THE WINNER IS {} {}'.format(i+1,reName[i],maxi[i]))
       
       













