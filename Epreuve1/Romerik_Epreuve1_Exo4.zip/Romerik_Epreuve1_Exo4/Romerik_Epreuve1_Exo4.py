#coding:utf-8
"""
Author : Romerik LOKOSSOU from Contest_Coding
Date : 16 September 2021
"""
def search(x_search,y_search,x_find,y_find,character):
    global is_find
    if is_find==1:
        return
    if x_search==x_find and y_search==y_find:
        is_find = 1
    else:
        if (x_search, y_search) not in positions:
            positions.append((x_search, y_search))
        to_search = [(x_search-1,y_search), (x_search+1,y_search), (x_search,y_search-1), (x_search,y_search+1)]
        for (a,b) in to_search:
            if a>=0 and a<W and b>=0 and b<L and (a,b) not in positions:
                positions.append((a,b))
                if prison[a][b]==character:
                    search(a,b,x_find,y_find,character)

results = list()
P = int(input())
for i in range(P):
    is_find = 0
    L, W, A, B, C, D = [int(j) for j in input().split()]
    prison = list()
    for k in range(W):
        prison.append(list(input()))
    prison.reverse()
    A-=1
    B-=1
    C-=1
    D-=1
    positions = list()
    search(B,A,D,C,prison[A][B])
    if is_find==0:
        results.append("NO")
    else:
        results.append("YES")

for result in results:
    print(result)
