              Produit par LOKOSSOU Romérick2
              Num: +229 94062298
              email: eeric5756@gmail.com
              Github: github.com/romerick
       
1-) Avoir au moins python3.6
2-) Exécuter le script en tapant : python Romerik_Epreuve1_Exo4.py
