Ce programme est la solution de l'exercice 2  écrite en langage C.

Vous pouvez le copier et le coller dans codeblocks et l'executer.

Neanmoins, si vous desirez le faire en ligne de commande, redirigez 

vous dans le dossier du stockage du fichier et executez les commandes suivantes:

--> gcc  main.c -o main
--> .\main

Entrez les données telleque sur l'ennoncé.
