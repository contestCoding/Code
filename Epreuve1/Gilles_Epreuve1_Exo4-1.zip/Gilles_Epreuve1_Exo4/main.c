#include<stdio.h>
#include<stdlib.h>
int check(int l,int w,int a,int b,int c,int d,char lettre,int cas,char tab[][20],int da,int db);
int check(int l,int w,int a,int b,int c,int d,char lettre,int cas,char tab[][20],int da,int db)
{   int suite=0;
    if(a!=da && b!=db){ 
    if(a<l && tab[a+1][b]==lettre && cas!=4)
    {   if(a+1==c && b==d)
            return 1;
        else
            suite=check(l,w,a+1,b,c,d,lettre,1,tab,da,db); }
    if(b<w && tab[a][b+1]==lettre && suite!=1 && cas!=3)
    {   if(a==c && b+1==d)
            return 1;
        else
            suite=check(l,w,a,b+1,c,d,lettre,2,tab,da,db); }
    if(b>0 && tab[a][b-1]==lettre && suite!=1 && cas!=2)
    {   if(a==c && b-1==d)
            return 1;
        else
            suite=check(l,w,a,b-1,c,d,lettre,3,tab,da,db); }
    if(a>0 && tab[a-1][b]==lettre  && suite!=1 && cas!=1)
    {   if(a-1==c && b==d)
            return 1;
        else
            suite=check(l,w,a-1,b,c,d,lettre,4,tab,da,db); }    }
    return suite;   }
int main()
{   int cas=0,i=0,j=0,k=0;
    scanf("%d",&cas);
    char tab[20][20],buffer;
    int l,w,a,b,c,d,resultat[cas];
    while(i<cas)
    {   scanf("%d %d %d %d %d %d ",&w,&l,&b,&a,&d,&c);
        l--;w--;d--;b--;a=l-a+1;c=l-c+1;
        j=0;
        while(j<=l)
        {   k=0;
            while(k<=w)
            {   tab[j][k]=getchar();
                if(k==w)
                    buffer=getchar();
                k++;    }
            j++;    }
        if(a==c && b==d)
            resultat[i]=1;
        else if(tab[a][b]==tab[c][d])
            resultat[i]=check(l,w,a,b,c,d,tab[a][b],0,tab,a,b);
        else
            resultat[i]=0;
        i++;    }
    i=0;
    while(i<cas)
    {   if(resultat[i]==1)
            printf("\nYES\n");
        else
            printf("\nNO\n");
        i++;    }
    return 0;   }
