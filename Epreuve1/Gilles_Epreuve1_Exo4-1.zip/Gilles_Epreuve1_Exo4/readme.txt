1-Ouvrez le fichier dans vos IDE munir de compilateur et compilez-le ,
ou à l'aide de la commande "gcc fichier.c -o programme_à_executer" ,compiler-le en ligne de commande.
